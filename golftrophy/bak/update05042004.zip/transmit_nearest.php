<html>
<head>
<title>Golf Event 2004 - Daten�nderung
</title>
</head>
<body>
<?php
echo "<table><tr><a href='index.html'><img src='uwe-links.jpg' width='300' border='0' alt='Golf Event 2004'></a></tr>";
echo "</table>";
?>
<h3>Daten�nderung</h3>
<?php
//echo "recordID=$recordID";
	//To find back to the flight
	$db = mysql_connect();
	$res = mysql_db_query("golfer2004","select * from golfer where ID=$recordID");
	$num = mysql_num_rows($res);
	$altfl = mysql_result($res, 0, "flight");
	$altna = mysql_result($res, 0, "name");

	if (!num)
		{
		echo "Uuups, something strange. Could not find record for ID=$recordID";
		}
	else
		{
		$fli = mysql_result($res, $i, "Flight");
		//echo "Flight=$fli";
		}
	$error=0;
	if ($neune=="")
		{ echo "Fehler: Nearest ist leer!<p>";
		$error=1;
		}
	if ($neulo=="")
		{ echo "Fehler: Longest ist leer!<p>";
		$error=1;
		}
	if (!is_numeric($neune))
		{
		echo "$neune: Nearest ist keine korrekte Zahl!<p>";
		$error=1;
		}
	if (!is_numeric($neulo))
		{
		echo "$neulo: Longest ist keine korrekte Zahl!<p>";
		$error=1;
		}
	if (!$error==1)
		{
		$db = mysql_connect();

		$sqlab = "update golfer set ";
		$sqlab .= "nearest=$neune, ";
		$sqlab .= "longest=$neulo ";
		$sqlab .= "where id=$recordID";

		mysql_db_query("golfer2004", $sqlab);

		$num = mysql_affected_rows();
		if ($num>0)
			{
			//echo "Fli=$fli";
			echo "Der Datensatz f�r $altna, Flight $altfl wurde erfolgreich ge�ndert<p>";
			}
		else
			{
			echo "'$sqlab'<p>";
			echo "<b>Der Datensatz wurde nicht ge�ndert!</b><p>";
			echo mysql_error() . "<p>";
			}
		mysql_close($db);
		}
		else
			echo "Es wurden keine Daten ge�ndert!<p>";
echo "<h3><a href='flight.php?flight=$fli'>Zur�ck</a></h3>";
?>

</body>
</html>

