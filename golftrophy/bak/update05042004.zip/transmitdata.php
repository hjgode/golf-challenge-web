<html>
<body>
<h2><a href="index.html">Golf Event 2004</a></h2>
<h3>Daten�nderung</h3>
<?php
//echo "recordID=$recordID";
	$error=0;
	if ($neuna=="")
		{ echo "Fehler: Leerer Name!<p>";
		$error=1;
		}
	if ($neulo=="" || $neune=="")
		{ echo "Fehler: Longest oder Nearest ist leer!<p>";
		$error=1;
		}
   $db = mysql_connect();
   $res = mysql_db_query("golfer2004","select * from golfer WHERE Flight='$neufl' AND name='$neuna' AND id<>$recordID");
   $num = mysql_num_rows($res);
	if ($num>0)
		{ echo "Name ist im Flight $neufl schon vorhanden!<p>";
		$error=1;
		}

	if (!$error==1)
		{
		$db = mysql_connect();

		$sqlab = "update golfer set flight='$neufl', ";
		$sqlab .= "name='$neuna', ";
		$sqlab .= "geschlecht='$neuge', ";
		$sqlab .= "nearest=$neune, ";
		$sqlab .= "longest=$neulo ";
		$sqlab .= "where id=$recordID";

		mysql_db_query("golfer2004", $sqlab);

		$num = mysql_affected_rows();
		if ($num>0)
			echo "Der Datensatz wurde ge�ndert<p>";
		else
			{
			echo "'$sqlab'<p>";
			echo "<b>Der Datensatz wurde nicht ge�ndert!</b><p>";
			echo mysql_error() . "<p>";
			}
		mysql_close($db);
		}
		else
			echo "Es wurden keine Daten ge�ndert!<p>";
?>
Zur�ck zur <a href="editdata.php">Auswahl</a>

</body>
</html>

