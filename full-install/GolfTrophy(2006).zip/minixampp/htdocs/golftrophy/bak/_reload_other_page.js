    <script language=javascript>
     var TickerTime = 30000;
        function tickern()
   {
       location.href="results_m.php" ;
   }
      setTimeout( "tickern()", TickerTime );
    </script>



<meta http-equiv="refresh" content="10;url=results_m.php">
