<html>
<head>
<meta name="author" content="KKay Vogelgesang">
<link href="xampp.css" rel="stylesheet" type="text/css">
</head>

<body>
<? include("lang/".file_get_contents("lang.tmp").".php"); ?>

&nbsp;<p>
<h1><?=$TEXT['mail-head']?></h1>
<table width=600 cellpadding=0 cellspacing=0 border=0>
<tr>
<td align=left width="600">
<?=$TEXT['mail-help1']?>
<?=$TEXT['mail-help2']?>
<?=$TEXT['mail-url']?>
</td>
</tr>
  </table>



</body>
</html>
