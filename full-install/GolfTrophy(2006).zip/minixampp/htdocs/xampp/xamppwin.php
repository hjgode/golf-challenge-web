<html>
<head>
<meta name="author" content="Kay Vogelgesang">
<link href="xampp.css" rel="stylesheet" type="text/css">
</head>

<body>
<? include("lang/".file_get_contents("lang.tmp").".php"); ?>
&nbsp;<p>
<h1><?=$TEXT['manuals-head']?></h1>

<?=$TEXT['manuals-text1']?>
<?=$TEXT['manuals-list1']?>
<?=$TEXT['manuals-text2']?>
<?=$TEXT['manuals-list2']?>
<?=$TEXT['manuals-text3']?>


</body>
</html>
